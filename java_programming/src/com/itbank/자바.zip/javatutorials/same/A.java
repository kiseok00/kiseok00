package com.itbank.javatutorials.same;

public class A {
	private int num;

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}
	
	
	//getter �� setter
	

}
