package com.itbank.javatutorials.same;

class DefaultClass {

}
