package com.itbank.javatutorials.same;

public class PublicClass {

}
