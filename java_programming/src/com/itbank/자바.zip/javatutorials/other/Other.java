package com.itbank.javatutorials.other;

public class Other {
	public void _public() {
		System.out.println("public");
		
	}
	protected void _protected() {
		System.out.println("protected");
		
	}
	void _default() {
		System.out.println("default");
		
	}
	private void _private() {
		System.out.println("private");
	}
	
}
