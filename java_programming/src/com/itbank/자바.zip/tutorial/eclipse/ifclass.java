package com.itbank.tutorial.eclipse;

public class ifclass {
	
	public static int conditionTest(int value) {
		int ret =0;
		if(value %3==0) ret =3;
		else if(value %4==0) ret=4;
		else ret=-1;
		return ret;
		
	}

	public static void main(String[] args) {
		/*int i =4;
		if(i*2>5) {
			System.out.println("TRUE");
		}
		else {
			System.out.println("FALSE");
		}
		
	}*/
		boolean isSuccess =false;
		if(!isSuccess) {
			System.out.println("true");
		}

		

	}
	
}
